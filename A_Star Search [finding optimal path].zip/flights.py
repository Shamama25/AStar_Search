import heapq
import matplotlib.pyplot as plt
import networkx as nx


class FlightProblem:
    def __init__(self, initial, goal, flights, heuristics):
        self.initial = initial
        self.goal = goal
        self.flights = flights
        self.heuristics = heuristics

    def actions(self, state):
        return self.flights[state].keys()

    def result(self, state, action):
        return action

    def is_goal(self, state):
        return state == self.goal

    def cost(self, state1, action, state2):
        return self.flights[state1][state2]

    def heuristic(self, state):
        return self.heuristics[state]


def astar_search(problem):
    frontier = []
    heapq.heappush(frontier, (0, problem.initial))
    came_from = {problem.initial: None}
    cost_so_far = {problem.initial: 0}

    while frontier:
        _, current = heapq.heappop(frontier)

        if problem.is_goal(current):
            break

        for action in problem.actions(current):
            new_cost = cost_so_far[current] + problem.cost(current, None, action)
            if action not in cost_so_far or new_cost < cost_so_far[action]:
                cost_so_far[action] = new_cost
                priority = new_cost + problem.heuristic(action)
                heapq.heappush(frontier, (priority, action))
                came_from[action] = current

    return came_from, cost_so_far


def reconstruct_path(came_from, start, goal):
    current = goal
    path = []
    while current != start:
        path.append(current)
        current = came_from[current]
    path.append(start)
    path.reverse()
    return path


def read_flights(file_path):
    flights = {}
    heuristics = {}
    with open(file_path, "r") as f:
        lines = f.readlines()
        for line in lines:
            parts = line.split()
            node = parts[0]
            heuristic = int(parts[1])
            heuristics[node] = heuristic
            connections = {}
            for i in range(2, len(parts), 2):
                connections[parts[i]] = int(parts[i + 1])
            flights[node] = connections
    return flights, heuristics


def plot_graph(flights, path, total_distance):
    G = nx.DiGraph()
    for node, edges in flights.items():
        for destination, weight in edges.items():
            G.add_edge(node, destination, weight=weight)

    pos = nx.spring_layout(G)
    plt.figure(figsize=(10, 7))
    nx.draw(
        G,
        pos,
        with_labels=True,
        node_color="#99DBF5",
        node_size=1800,
        edge_color="#9BABB8",
        linewidths=1,
        font_size=8,
    )
    path_edges = list(zip(path, path[1:]))
    nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color="#FF0000", width=2)
    nx.draw_networkx_nodes(G, pos, nodelist=path, node_color="#FFB319", node_size=1900)
    labels = nx.get_edge_attributes(G, "weight")
    nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)

    plt.show()


def main():
    file_path = "flights.txt"
    flights, heuristics = read_flights(file_path)

    start = input("Start node: ")
    goal = input("Destination: ")

    if start not in flights or goal not in flights:
        print("Start or destination node not found in the graph.")
        return

    problem = FlightProblem(start, goal, flights, heuristics)
    came_from, cost_so_far = astar_search(problem)

    if goal in came_from:
        path = reconstruct_path(came_from, start, goal)
        total_distance = cost_so_far[goal]
        print(f"Path: {' → '.join(path)}")
        print(f"Optimal Path with Total Distance: {total_distance} km")
        plot_graph(flights, path, total_distance)
    else:
        print("Path does not exist.")


if __name__ == "__main__":
    main()
